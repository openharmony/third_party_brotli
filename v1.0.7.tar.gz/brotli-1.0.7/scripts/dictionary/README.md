Set of tools that can be used to download brotli RFC, extract and validate
binary dictionary, and generate dictionary derivatives
(e.g. Java `DictionaryData` class constants).
